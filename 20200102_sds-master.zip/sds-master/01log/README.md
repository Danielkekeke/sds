# Logback

## demo api

1. [normal](http://localhost:8080/demo/first)
2. [exception](http://localhost:8080/demo/exception)
3. [level](http://localhost:8080/demo/level)
4. [version](http://localhost:8080/demo/version)