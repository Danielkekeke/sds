package tw.elliot.log.service;

import tw.elliot.log.ctrl.DemoController;

public class ServerA {

    public void methodA(String param) {
        String name = DemoController.mdc.get();
        System.out.println(name+ "   AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
    }
}
