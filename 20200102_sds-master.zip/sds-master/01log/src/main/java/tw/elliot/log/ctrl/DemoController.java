package tw.elliot.log.ctrl;

import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import tw.elliot.log.entity.User;
import tw.elliot.log.service.ServerA;
import tw.elliot.log.service.ServerB;

@RestController
@Slf4j
@RequestMapping("/demo")
public class DemoController {
	public static ThreadLocal<String> mdc = new ThreadLocal<>();
	public DemoController() {
		super();
		log.info("create controller instance");
	}

	@GetMapping("/first")
	public String first() {
		log.info("Check this !");
		return "It's ok!";
	}

	@GetMapping("/exception")
	public String exception() {
		log.error("Create Exception Log");
		throw new RuntimeException("I don't care");
	}

	@GetMapping("/level")
	public String level() {
		log.debug("a debug test");
		log.warn("Fake warning message!");
		return "test level success!";
	}

	@GetMapping("/version")
	public String version() {
		Package pack = DemoController.class.getPackage();
		log.info("pack is {}", pack);

		log.info("package imp: {}", pack.getImplementationVersion());

		return pack.getImplementationVersion();
	}

	@GetMapping("/mdc")
	public String mdc() {

		mdc.set("Tim");
		ServerA a = new ServerA();
		ServerB b = new ServerB();

		a.methodA("");
		b.methodB("");

		return "OK";
	}
}
