package tw.elliot.log.service;

import tw.elliot.log.ctrl.DemoController;

public class ServerB {
    public void methodB(String param) {
        String name = DemoController.mdc.get();
        System.out.println(name + " ---- BBBBBBBBBBBBB");
    }
}
