package tw.elliot.log.service;

import tw.elliot.log.ctrl.DemoController;

public class ServerC {
    public void methodC(String parm) {
        String name = DemoController.mdc.get();
        System.out.println(name + "CCCCCCCCCCCCCCCCCCCCCCC");
    }
}
